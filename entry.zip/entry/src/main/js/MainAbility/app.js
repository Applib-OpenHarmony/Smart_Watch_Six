export default {
    onCreate() {
        console.info("Application onCreate");
    },
    onDestroy() {
        console.info("Application onDestroy");
    }
};
